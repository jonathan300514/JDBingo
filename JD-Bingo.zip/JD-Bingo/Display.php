<?php

$PageAddress = "https://www.jd-sh.co.uk/dj/index.php";
$PageTitle = "JD-Bingo";
$Keywords = "HTML,CSS,XML,JavaScript,PHP,Bingo,Web-App";
$PageDisc = "A simple bingo app allowing remote control from secondary device";
$FrontImgAddress = "https://www.jd-sh.co.uk/dj/assets/download.jpg";
$TwitterTag = "@jonathan300514";
$CreateTime = "2018-12-29T00:23:00+01:00";
$EditTime = "2018-04-29T00:23:00+01:00";
$LogoImg = "https://www.jd-sh.co.uk/dj/assets/thelogo.png";

?>
<!DOCTYPE html>


<html itemscope itemtype="<?php echo $PageAddress ?>" lang="en">

	<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	  <meta name="viewport" content="width=device-width, initial-scale=1"/>
	  <title><?php echo $PageTitle ?></title>
    <meta name="keywords" content="<?php echo $Keywords ?>">

	   <!-- Update your HtMl tag to include the itemscope and itemtype attributes. -->

	<!-- Place this data between the <head> tags of your website -->

	<meta name="description" content="<?php echo $PageDisc ?>"/>
	<!-- Schema.org markup for Google+ -->
	<meta itemprop="name" content="<?php echo $PageTitle ?>"/>
	<meta itemprop="description" content="<?php echo $PageDisc ?>"/>
	<meta itemprop="image" content="<?php echo $FrontImgAddress ?>"/>
	<!-- Twitter Card data -->
	<meta name="twitter:card" content="summary_large_image"/>
	<meta name="twitter:site" content="<?php echo $TwitterTag ?>"/>
	<meta name="twitter:title" content="<?php echo $PageTitle ?>"/>
	<meta name="twitter:description" content="<?php echo $PageDisc ?>"/>
	<meta name="twitter:creator" content="<?php echo $TwitterTag ?>"/>
	<!-- Twitter summary card with large image must be at least 280x150px -->
	<meta name="twitter:image:src" content="<?php echo $FrontImgAddress ?>"/>
	<!-- Open Graph data -->
	<meta property="og:title" content="<?php echo $PageTitle ?>"/>
	<meta property="og:type" content="website"/>
	<meta property="og:url" content="<?php echo $PageAddress ?>"/>
	<meta property="og:image" content="<?php echo $FrontImgAddress ?>"/>
	<meta property="og:description" content="<?php echo $PageDisc ?>"/>
	<meta property="og:site_name" content="<?php echo $PageTitle ?>"/>
	<meta property="article:published_time" content="<?php echo $CreateTime ?>"/>
	<meta property="article:modified_time" content="<?php echo $EditTime ?>"/>
	<meta property="article:section" content="Article Section"/>
	<meta property="article:tag" content="Article Tag"/>
	<!-- DEVICE ICONS -->
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<link rel="icon" href="<?php echo $LogoImg ?>">
	<link rel="shortcut icon" href="<?php echo $LogoImg ?>" />
	<link rel="apple-touch-icon" href="<?php echo $LogoImg ?>"/>
	<link rel="apple-touch-icon-precomposed" href="<?php echo $LogoImg ?>"/>

  <!-- CSS  -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
	<link href="css/Scroll.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
		<script>

  $(document).ready(function(){
    $('.modal').modal();

  });

</script>

<style>

.modalRandom {
   max-height: 100%;
	 text-align: center;
}


</style>
</head>
<body style="margin:0px">
  <div class="row" style="margin-bottom:0px;">
            <h1 id="Call" class="center CalledNumber"></h1>
    </div>
	
<style>

h1.CalledNumber{
	font-weight: 600;
	font-size: 50em;
	margin: 0.0em 0 !important;

}

</style>

		<!-- Modal Structure -->
	   <div id="modalBingo" class="modal" style="background-color: transparent;">
	     <div class="modal-content">

				 <h1 id="Bingo!" align="center" style="text-transform: uppercase; font-size: 180px; color: #FF69B4;" class="hvr-pulse"><strong>Bingo!</strong></h1>

	     </div>
	   </div>

		 <!-- Modal Structure -->
 	   <div id="modalRandom" class="modal RandModal" style="background-color: grey;">
 	     <div class="modal-content">

 				 <span id="RandomNum" class='numscroller hvr-pulse Rand center' align="center" style="text-transform: uppercase; text-align: center; font-size: 300px; color: #FF69B4; top: 0%;" data-min='1' data-max='500' data-delay='5' data-increment='4'></span>

 	     </div>
 	   </div>


    <!--<div class="row">
        <div class="col s4 m2">
          <div class="card blue-grey darken-1">
            <div class="col s6">
              <h5>Number of calls</h5>
							<h1 id="NumsCall"></h1>
            </div>
            <div class="card-content white-text">
              <h1 id="LCall"></h1>
            </div>

          </div>
        </div>
      </div>-->

  <div class="container">
    <div class="section">

      <!--Number Being called-->
        <p id="Call"></p>
      <!--Last number Called -->
      <!--<p id="LCall" onChange="check_user();" ></p>-->
      <!--Count of numbers Called.-->
      <!--<p id="NumsCall"></p>-->
        <!--<button onclick="Call()">Click me</button>-->
<p id="demo"></p>
      <script>


      let Calling = ["1", "2", "3", "4", "5", "6", "7", "8", "9",
      "10", "11", "12", "13", "14", "15", "16", "17", "18", "19",
      "20", "21", "22", "23", "24", "25", "26", "27", "28", "29",
      "30", "31", "32", "33", "34", "35", "36", "37", "38", "39",
      "40", "41", "42", "43", "44", "45", "46", "47", "48", "49",
      "50", "51", "52", "53", "54", "55", "56", "57", "58", "59",
      "60", "61", "62", "63", "64", "65", "66", "67", "68", "69",
      "70", "71", "72", "73", "74", "75", "76", "77", "78", "79",
      "80", "81", "82", "83", "84", "85", "86", "87", "88", "89",
      "90"];

function Jumble() {
      Calling.sort(function(a, b){return 0.5 - Math.random()});
    }
    Jumble();
      let text = " ";
      let i = 0;
      let Called = '00';
      let LastCalled = '00';
      let First = 0;
      let NumberSetVal = 0;
			let CalledClr = "#03a9f4";
			let ResetClr = "black";

      $( document ).ready(function() {
    Call();
    ResetPage();
});


      function Call() {
        if (First == 1) {
          LastCalled = Calling[i];
            i++
        } else {
          First = 1;

        }


        Called = Calling[i];

        $("#Call").text(Called);

        $("#" + Called).css("color", CalledClr);

        $("#NumsCall").text( i + 1 );

        $("#LCall").text(LastCalled);

      }





      //document.getElementById("demo").innerHTML = value1;
      /*$Bingo = array("$value1");*/
      let stored = localStorage['Bingo'];
      if (stored) myVar = JSON.parse(stored);
      else myVar = {a:'Son', b: [3, 2, 1]};

      // set interval
      var tid = setInterval(loadDoc, 50);

      function loadDoc() {

              let stored = localStorage['Bingo'];
              if (stored) myVar = JSON.parse(stored);
              else myVar = {a:'Son', b: [3, 2, 1]};

if (myVar.BingoCall === "1") {

$('#modalBingo').modal('open');

} else {

$('#modalBingo').modal('close');

}


if (myVar.ShowRand === "1") {

$('#modalRandom').modal('open');

} else {

$('#modalRandom').modal('close');

}

RandomNum = myVar.RandNum;

        $("#RandomNum").text(RandomNum);



              myVar.NumCalled = Called;
              myVar.LCalled = LastCalled;
              localStorage['Bingo'] = JSON.stringify(myVar);


if (myVar.Reset === "1") {
  //document.getElementById("demo").innerHTML = "myObj.CalledNumb";
  ResetPage();
} else {
                if (myVar.Paused === "0") {
                if (myVar.CalledNumb[NumberSetVal] === "1") {
                  Call();
                  NumberSetVal++;
                    }
                }
              }
};



      function ResetPage() { // called to reset
        NumberSetVal = 0;
        Called = "00";
        LastCalled = "00";
        Jumble();
        i = -1;
        $(".grid").css("color", ResetClr);
        $("#Call").text('00');
        $("#LCall").text('00');
        $("#NumsCall").text('0');
      }





      </script>

    </div>
    <br><br>
  </div>

  <!--  Scripts-->

  <script src="js/materialize.js"></script>
  <script src="js/init.js"></script>

  </body>
</html>
